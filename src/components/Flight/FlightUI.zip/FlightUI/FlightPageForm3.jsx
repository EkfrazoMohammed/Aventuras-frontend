import React,{useState,useEffect,useRef,useMemo} from 'react'
import {Link} from "react-router-dom"
import "./FlightPageForm.scss"
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import axios from "axios";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

import Avatar from '@mui/material/Avatar';
import Menu from '@mui/material/Menu';
import ListItemIcon from '@mui/material/ListItemIcon';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import PersonAdd from '@mui/icons-material/PersonAdd';
import Settings from '@mui/icons-material/Settings';
import Logout from '@mui/icons-material/Logout';
// import { Radio, Select, Space } from 'antd';
import CribIcon from '@mui/icons-material/Crib';
import StrollerIcon from '@mui/icons-material/Stroller';
import ChildFriendlyIcon from '@mui/icons-material/ChildFriendly';
import ChildCareIcon from '@mui/icons-material/ChildCare';
import PersonIcon from '@mui/icons-material/Person';
import { styled } from '@mui/material/styles';

import { API, baseURL } from '../../../api/apirequest';

import { message} from 'antd';
import { notification } from 'antd';
import { set } from 'date-fns';

const FlightPageForm = () => {

    const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
    const options = [
        { value: '', label: 'Select Destination' },
        { value: 'BLR', label: 'Bengaluru (BLR)' },
        { value: 'HYD', label: 'Hyderabad (HYD)' },
        { value: 'BOM', label: 'Mumbai (BOM)' },
        { value: 'DEL', label: 'Delhi (DEL)' },
        { value: 'MAA', label: 'Chennai (MAA)' },
        { value: 'CCU', label: 'Kolkata (CCU)' },
        
      ];
      const flight_class_options = [
    { value: 'ECONOMY', label: 'ECONOMY' },
    { value: 'SPECIAL (NON-REFUNDABLE)', label: 'SPECIAL (NON-REFUNDABLE)' },
    { value: 'REFUNDABLE', label: 'REFUNDABLE' },
    { value: 'CORPORATE', label: 'CORPORATE' },
    
    ];
    const [selectedFromOption, setSelectedFromOption] = useState(null);
 const today = new Date ()
      const ticketing_way = [{ value:true, label: 'One Way' },{ value: false, label: 'Round Trip' },];
      const [data, setData] = useState({
        // user_name: '',
        user_email: '',
        user_mobile_number:null,
        request_origin: '',
        request_destination: '',
        departure:{today},
        arrival:'',
        flight_class: 'ECONOMY',
        direct_flight: true,
        one_way: true,
        adults:1,
        children: 0,
        infants: 0,
      });

      const [validationErrors, setValidationErrors] = useState({
        user_mobile_number: false,
    });


    const [errorHandling, setErrorHandling] = useState({
      user_email: '',
      user_mobile_number:null,
      request_origin: '',
      request_destination: '',
      departure:'',
     });

     let arrayError = [errorHandling]

      const handleChange = (name, value) => {
        if (name === "request_origin") {
          setSelectedFromOption(value);
          setErrorHandling({ ...errorHandling, request_origin: "" });
        }
        if (name === "user_email") {
          setErrorHandling({ ...errorHandling, user_email: "" });
        }
        if (name === "user_mobile_number") {
          setErrorHandling({ ...errorHandling, user_mobile_number: "" });
        }
        if (name === "request_destination") {
          setErrorHandling({ ...errorHandling, request_destination: "" });
        }  
           if (name === "departure") {
          setErrorHandling({ ...errorHandling, departure: "" });
        }

        setData((prevData) => ({
          ...prevData,
          [name]: value,
        }));
        

      };

      console.log(data)
const [count,setCount]=useState(0);
const toOptions = options.filter(option => option.value !== selectedFromOption);

    const updateAdults = (newAdults) => {
        setData((prevData) => ({
          ...prevData,
          adults: newAdults,
        }));
      };
      const updateChildren = (newChildren) => {
        setData((prevData) => ({
          ...prevData,
          children: newChildren,
        }));
      };
      const updateInfants = (newInfants) => {
        setData((prevData) => ({
          ...prevData,
          infants: newInfants,
        }));
      };

      const Counter = ({ count, onCountChange }) => {
        const handleIncrement = () => {
          onCountChange(count + 1);
        };
      
        const handleDecrement = () => {
            if (count > 0) {
                onCountChange(count - 1);
              }
        };
      
        return (
          <>
          <div className='counter-container' 
          style={{ display: "flex",
    gap: "8px",
    height: "auto",
    alignItems: "center",
    justifyContent: "center"
    }}
    >
            <div className="button-container" onClick={handleDecrement}
             style={{
               backgroundColor: "#ffe93d",
               border: "1px solid #eee",
               borderRadius: "50%",
               padding: "1rem",
               textAlign: "center",
               display:"flex",
               alignItems: "center",
               alignContent: "center",
               justifyContent: "center",
               width: "10px",
               height: "10px",
            }}>

            <span  className='counter-button' >-</span>
            </div>
              <span className='counter-count'>{count}</span>
              <div className="button-container" onClick={handleIncrement}  style={{
               backgroundColor: "#ffe93d",
               border: "1px solid #eee",
               borderRadius: "50%",
               padding: "1rem",
               textAlign: "center",
               display:"flex",
               alignItems: "center",
               alignContent: "center",
               justifyContent: "center",
               width: "10px",
               height: "10px",
            }}>

            <span  className='counter-button'>+</span>
            </div>
            </div>
          </>
        );
      };
      




      const handleSubmit = async (e) => {
        e.preventDefault();
        
        const errors = {
          user_email: !data.user_email,
          user_mobile_number: !data.user_mobile_number,
          request_origin: !data.request_origin,
          request_destination: !data.request_destination,    
          departure:!data.departure
      };
      const errorObject ={ }


      const validateEmailAndMobile = () => {
        let emailValid = false;
        let mobileValid = false;
      
        if (!errors.user_email) {
          if (!/^\S+@\S+\.\S+$/.test(data.user_email)) {
            errorObject.user_email = 'Enter a valid email address.';
            emailValid = false
          } else {
            errorObject.user_email = '';
            emailValid= true
          }
        }
      
        if (!errors.user_mobile_number) {
          if (!/^\d{10}$/.test(data.user_mobile_number)) {
            errorObject.user_mobile_number = 'Enter a valid 10-digit mobile number.';
            mobileValid = false
          } else {
            errorObject.user_mobile_number = '';
            mobileValid = true
          }
        }
      
        return emailValid && mobileValid;
      }

   
      
      
     
       if(errors.user_email){   
        errorObject.user_email = 'Enter Your Email'
      }
      if(errors.user_mobile_number){
        errorObject.user_mobile_number = 'Enter Your  Mobile Number'
      }
      if(errors.request_origin){
        errorObject.request_origin = 'Enter Your Origin Place'
      }  
       if(errors.request_destination){
        errorObject.request_destination = 'Enter Your Destination Place'
      }
   
         if(errors.departure){
        errorObject.departure = 'Enter Your Departure Date'
       }

setErrorHandling(errorObject)

      // if (Object.values(errors).some(error => error)) {
      //   // There are validation errors, show error notification and return
      //   // notification.error({
      //   //   message: 'Form Validation Error',
      //   //   description: 'Please fill all required fields before submitting the form.',
      //   //   duration: 2, // Duration in seconds (adjust as needed)
      //   // });
      //   return;
      // }
          setValidationErrors({});
        const config = {
          headers: {
            'Content-Type': 'application/json',
            // Add any other headers that are required for your API
          },
        };

   
        try {
          let ob = {data}
      console.log(ob)
      if(validateEmailAndMobile() && !errors.request_origin && !errors.request_destination && !errors.departure ){

  
          const res = await API.post(baseURL + 'api/flight-enquiries',ob, config);

          if(res.status==200){
            notification.success({
              message: 'Enquiry Sent successfully!',
              description: 'We will be in touch with provided email',
              duration: 2, // Duration in seconds (adjust as needed)
            });
            let mailData= {
       
              "email": `${data.user_email}`,
              "subject":`Flight Enquiry from ${data.user_email}`,
              "otp":`${data.user_email} has Enquired for flights from ${data.request_origin}  
              to ${data.request_destination}  with class ${data.flight_class}
              with contact_number :${data.user_mobile_number}`
        }
        let sendingMail=await axios.post("https://aventuras.co.in/api/v1/users/sendOTPMail",mailData)
console.log(sendingMail)

          }

          if(res.data.error.message==="user_email must be a valid email"){
            notification.error({
              message: 'user_email must be a valid email',
              duration: 2, // Duration in seconds (adjust as needed)
            });
          }
    
          

          setTimeout(()=>{
              window.location.reload();
          },1000)
        }
          // Perform any necessary actions after form submission
        } catch (error) {
          console.error('Error submitting form:', error);

        }
      };
      function getCurrentDate() {
        const now = new Date();
        const year = now.getFullYear();
        const month = (now.getMonth() + 1).toString().padStart(2, '0'); // Add 1 because months are 0-indexed
        const day = now.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
      }
      
  return (
<>
<div className="flight-container">
    <div className="flight-wrapper">

        <div className="flight-container-form">
        <div className="title">Flight Enquiry</div>
        <Paper>
        <div className="form-wrappper">
  <Grid className='flight-all-columns'>
        <Grid container className='flight-left-columns'>
        <Grid container spacing={2}  >
        <Grid item sm={12} md={3} >
        <TextField
  className="no-margin small-size"
  margin="normal"
  fullWidth
  label="Enter Your Email"
  type="text"
  id="user_email"
  name="user_email"
  value={data.user_email}
  onChange={(e) => handleChange('user_email', e.target.value)}  // Trim the value here
/>

{
  errorHandling.user_email ?  <span className="" style={{fontSize:'12px',color:'red',marginLeft:'5px'}}>
  *{ errorHandling.user_email}
  </span> : ''
}

        </Grid>
        
        <Grid item sm={12} md={3} >
        {/* <TextField  fullWidth id="outlined-basic" label="Outlined" variant="outlined" /> */}
                                           <TextField className="no-margin small-size"
                                            margin="normal"
                                            fullWidth
                                        
                                            label="Enter Mobile Number"
                                            type="number"
                                            id="user_mobile_number"
                                            value={data.user_mobile_number}
                                            name="user_mobile_number" 
                                            onChange={(e) => handleChange('user_mobile_number', parseInt(e.target.value) )} // Convert string back to boolean
                                        />
                                        {
  errorHandling.user_mobile_number ?  <span className="" style={{fontSize:'10px',color:'red'}}>
   *{  errorHandling.user_mobile_number}
  </span> : ''
}
        </Grid>
      
        <Grid item sm={12} md={3}>
      <Autocomplete
      className='small-size'
            disablePortal
            id="combo-box-demo-origin"
            options={options}
            getOptionLabel={(option) => option.label}
            name="request_origin"
            onChange={(e, value) => handleChange("request_origin", value.value)}
            renderInput={(params) => <TextField {...params} label="From" />}
            isOptionEqualToValue={(option, value) => option.value === value.value}
          />
{
  errorHandling.request_origin ?  <span className="" style={{fontSize:'12px',color:'red',marginLeft:'5px'}}> *{errorHandling.request_origin}</span> : ''
}
        </Grid>
        <Grid item sm={12} md={3}>
      <Autocomplete
        className='small-size'
        disablePortal
        id="combo-box-demo-origin"
        options={toOptions}
        getOptionLabel={(option) => option.label}
        name="request_destination"
        onChange={(e, value) => handleChange("request_destination", value.value)}
        renderInput={(params) => <TextField {...params} label="To" />}
        isOptionEqualToValue={(option, value) => option.value === value.value}
      />

{
  errorHandling.request_destination ?  <span className="" style={{fontSize:'12px',color:'red',marginLeft:'5px'}}> *{errorHandling.request_destination}</span> : ''
}
    </Grid>
          </Grid>
       <Grid container spacing={2}  >
       <Grid item sm={12} md={3} >
        <FormControl fullWidth variant="outlined">
        <InputLabel id="demo-simple-select-label" >Tier Type</InputLabel>
        <Select

        className='small-size'
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={data.flight_class} // Convert boolean to string
          label="Tier Type"
          name="flight_class"
          onChange={(e) => handleChange('flight_class', e.target.value )} // Convert string back to boolean
        
        >
       
            {flight_class_options.map((v) => (
           <MenuItem key={v.value} value={v.value}>
             {v.label}
           </MenuItem>
         ))}
        </Select>
      </FormControl>
      
               
     {/* <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item">
            <FormControl fullWidth>
                 {/* <Autocomplete
           disablePortal
           id="combo-box-demo-origin"
           options={flight_class_options}
           getOptionLabel={(option) => option.label}
           name="flight_class"
           onChange={(e, value) => handleChange("flight_class", value.value)}
           renderInput={(params) => <TextField {...params} label="Flight Class" />}
         /> 
           <InputLabel id="demo-simple-select-label" >Tier Type</InputLabel>
     
              <Select
              className='small-size'
         labelId="demo-simple-select-label"
         id="demo-simple-select"
         value={data.flight_class} // Convert boolean to string
         label="Flight Class"
         name="flight_class"
         onChange={(e) => handleChange('flight_class', e.target.value )} // Convert string back to boolean
       >
         {flight_class_options.map((v) => (
           <MenuItem key={v.value} value={v.value}>
             {v.label}
           </MenuItem>
         ))}
       </Select>
         </FormControl>  
       </MenuItem> */}
    
     </Grid>
       <Grid item sm={12} md={3} >
        <FormControl fullWidth variant="outlined">
        <InputLabel id="demo-simple-select-label" >Trip Mode</InputLabel>
        <Select

        className='small-size'
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={data.one_way} // Convert boolean to string
          label="one_way"
          name="one_way"
          onChange={(e) => handleChange('one_way', e.target.value )} // Convert string back to boolean
        >
          {ticketing_way.map((v) => (
            <MenuItem key={v.value} value={v.value}>
              {v.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
        {/* <FormControl fullWidth>
              
                 

<Autocomplete
disablePortal
            id="combo-box-demo-origin"
            options={ticketing_way}
            getOptionLabel={(option) => option.label}
            name="one_way"
            onChange={(e, value) => handleChange("one_way", value.value)}
            renderInput={(params) => <TextField {...params} label="Trip" />}
          />
                    </FormControl> */}
                  </Grid>
                  {/* <Grid item sm={12} md={3}> */}
                  {/* <FormControl fullWidth>
                  <Autocomplete
            disablePortal
            id="combo-box-demo-origin"
            options={flight_class_options}
            getOptionLabel={(option) => option.label}
            name="flight_class"
            onChange={(e, value) => handleChange("flight_class", value.value)}
            renderInput={(params) => <TextField {...params} label="Flight Class" />}
          /></FormControl> */}
                  {/* </Grid> */}
                  <Grid item sm={12} md={3}>
  <TextField
    className='small-size'
    fullWidth
    id="departure-date"
    label="Departure Date"
    type="date"
    name="departure"
    value={data.departure} // Set the value to the state value or an empty string
    onChange={(e) => { handleChange("departure", e.target.value) }}
    InputLabelProps={{
      shrink: true,
    }}
    inputProps={{ min: getCurrentDate() }}
  />
  {
  errorHandling.departure ?  <span className="" style={{fontSize:'12px',color:'red',marginLeft:'5px'}}> *{errorHandling.departure}</span> : ''
}
</Grid>

<Grid item sm={12} md={3}>
  {data.one_way === false && (
    <TextField
      className='small-size'
      fullWidth
      id="arrival-date"
      label="Arrival Date"
      type="date"
      name="arrival"
      value={data.arrival} // Set the value to the state value or an empty string
      onChange={(e) => { handleChange("arrival", e.target.value) }}
      InputLabelProps={{
        shrink: true,
      }}
      inputProps={{ min: getCurrentDate() }}

    />
  )}
</Grid>
       
             
  
       
        {/* <Grid item sm={12} md={3}>
       
<TextField
className='small-size'
  fullWidth
  id="departure-date"
  label="Departure Date"
  type="date"
  name="departure"
  value={data.departure} // Set the value to the state value
  onChange={(e) => {handleChange("departure", e.target.value)}} // Access the value from e.target.value
  InputLabelProps={{
    shrink: true,
  }}
/>
                  </Grid> 
                  
                   <Grid item sm={12} md={3}>
                  {data.one_way === false && (
                      <TextField

                      className='small-size'
                      
  fullWidth
  id="arrival-date"
  label="Arrival Date"
  type="date"
  name="arrival"
  value={data.arrival} // Set the value to the state value
  onChange={(e) => {handleChange("arrival", e.target.value)}} // Access the value from e.target.value
  InputLabelProps={{
    shrink: true,
  }}
/>
                  )}
                  </Grid>  */}
                
                 
                 
              
                  {/* <Grid item sm={12} md={3} className="flight-menu-container">
       <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }} >
       <Tooltip title="Passenger Details /Flight Class">
          {/* <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
          >
            {/* <Avatar sx={{ width: 32, height: 32 }}>M</Avatar>
            Traveller details
          </IconButton> 
          <Button variant="outlined"
          onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
            style={{
              padding: "1rem",
              margin: "0",
              width: "100%"
            }}
            className='small-size'
          >
            {/* <Avatar sx={{ width: 32, height: 32 }}>M</Avatar> 
            {`Passenger (${data.adults + data.children + data.infants}) / ${data.flight_class}`}

          </Button>
        </Tooltip>
      </Box>
      <Menu
     
      className="traveller-details"
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            minWidth: '210px !important',
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
        style={{
          minHeight: "auto",
  display: "flex",
  justifyContent: "space-between",
  gap:"1rem"
  }}>
        <ListItemIcon>
        <div className='list-item-text' 
        style={{display: "flex",
flexDirection: "column"}}
>
          <div className="upper-text">
            <div className='sub-text' style={{  display: "flex",
    alignItems: "center !important",
    alignContent: "center !important",
    justifyContent: "flex-start",
    gap: "6px"}}
    >
          <PersonIcon />
        <span>
Adults
        </span>
            </div>
         
          </div>
          <div className="lower-text"></div>
       
          {`(Age above 12 yrs)`}
        </div>
          
          </ListItemIcon>
        {/* <ListItemIcon>
        <div className='list-item-text'>
        <PersonIcon />
          Adults <br />
          {`Age > 12 yrs`}
        </div>
          </ListItemIcon> 
        <Counter count={data.adults} onCountChange={updateAdults} />
          
        </MenuItem>
       
<MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
style={{
  minHeight: "auto",
display: "flex",
justifyContent: "space-between",
gap:"1rem"
}}>
        <ListItemIcon>
        <div className='list-item-text' 
        style={{display: "flex",
flexDirection: "column"}}
>
          <div className="upper-text">
          <div className='sub-text' style={{  display: "flex",
    alignItems: "center !important",
    alignContent: "center !important",
    justifyContent: "flex-start",
    gap: "6px"}}
    >
            <ChildCareIcon />
        <span>

        Children 
        </span>
            </div>
         
          </div>
          <div className="lower-text"></div>
       
          {`(Age 2 to 12 yrs)`}
        </div>
          
          </ListItemIcon>
        <Counter count={data.children} onCountChange={updateChildren} />
        </MenuItem>
          

        <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
       style={{
        minHeight: "auto",
display: "flex",
justifyContent: "space-between",
gap:"1rem"
}}>

          {/* <ListItemIcon>
            <Settings fontSize="small" />
          </ListItemIcon>
           <ListItemIcon>
           <div className='list-item-text' 
        style={{display: "flex",
flexDirection: "column"}}
>
          <div className="upper-text">
          <div className='sub-text' style={{  display: "flex",
    alignItems: "center !important",
    alignContent: "center !important",
    justifyContent: "flex-start",
    gap: "6px"}}
    >
        <ChildFriendlyIcon />
        <span>Infants
        </span>
            </div>
         
          </div>
          <div className="lower-text"></div>
       
          {`(Age below 2 yrs)`}
        </div>
          
          </ListItemIcon>
          <Counter count={data.infants} onCountChange={updateInfants} />
        </MenuItem>
        {/* <Divider /> */}
        {/* <MenuItem onClick={handleClose}>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem> 
             <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item">
             <FormControl fullWidth>
                  {/* <Autocomplete
            disablePortal
            id="combo-box-demo-origin"
            options={flight_class_options}
            getOptionLabel={(option) => option.label}
            name="flight_class"
            onChange={(e, value) => handleChange("flight_class", value.value)}
            renderInput={(params) => <TextField {...params} label="Flight Class" />}
          /> 
            <InputLabel id="demo-simple-select-label" >Tier Type</InputLabel>
      
               <Select
               className='small-size'
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={data.flight_class} // Convert boolean to string
          label="Tier Type"
          name="flight_class"
          onChange={(e) => handleChange('flight_class', e.target.value )} // Convert string back to boolean
        >
          {flight_class_options.map((v) => (
            <MenuItem key={v.value} value={v.value}>
              {v.label}
            </MenuItem>
          ))}
        </Select>
          </FormControl>  
        </MenuItem>
      </Menu>
       </Grid> */}

     
                  </Grid>
                  
                  </Grid>
                 <Grid container spacing={2} className='flight-right-columns'>
                  <div
     
     className="traveller-details"
       anchorEl={anchorEl}
       id="account-menu"
       open={open}
       onClose={handleClose}
       onClick={handleClose}
       PaperProps={{
         elevation: 0,
         sx: {
           overflow: 'visible',
           filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
           mt: 1.5,
           minWidth: '210px !important',
           '& .MuiAvatar-root': {
             width: 32,
             height: 32,
             ml: -0.5,
             mr: 1,
           },
           '&:before': {
             content: '""',
             display: 'block',
             position: 'absolute',
             top: 0,
             right: 14,
             width: 10,
             height: 10,
             bgcolor: 'background.paper',
             transform: 'translateY(-50%) rotate(45deg)',
             zIndex: 0,
           },
         },
       }}
       transformOrigin={{ horizontal: 'right', vertical: 'top' }}
       anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
     >
       <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
       style={{
         minHeight: "auto",
 display: "flex",
 justifyContent: "space-between",
 gap:"1rem"
 }}>
       <ListItemIcon>
       <div className='list-item-text' 
       style={{display: "flex",
flexDirection: "column"}}
>
         <div className="upper-text">
           <div className='sub-text' style={{  display: "flex",
   alignItems: "center !important",
   alignContent: "center !important",
   justifyContent: "flex-start",
   gap: "6px"}}
   >
         <PersonIcon />
       <span>
Adults
       </span>
           </div>
        
         </div>
         <div className="lower-text"></div>
      
         {`(Age above 12 yrs)`}
       </div>
         
         </ListItemIcon>
       {/* <ListItemIcon>
       <div className='list-item-text'>
       <PersonIcon />
         Adults <br />
         {`Age > 12 yrs`}
       </div>
         </ListItemIcon> */}
       <Counter count={data.adults} onCountChange={updateAdults} />
         
       </MenuItem>
      
<MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
style={{
 minHeight: "auto",
display: "flex",
justifyContent: "space-between",
gap:"1rem"
}}>
       <ListItemIcon>
       <div className='list-item-text' 
       style={{display: "flex",
flexDirection: "column"}}
>
         <div className="upper-text">
         <div className='sub-text' style={{  display: "flex",
   alignItems: "center !important",
   alignContent: "center !important",
   justifyContent: "flex-start",
   gap: "6px"}}
   >
           <ChildCareIcon />
       <span>

       Children 
       </span>
           </div>
        
         </div>
         <div className="lower-text"></div>
      
         {`(Age 2 to 12 yrs)`}
       </div>
         
         </ListItemIcon>
       <Counter count={data.children} onCountChange={updateChildren} />
       </MenuItem>
         

       <MenuItem onClick={(e) => {e.stopPropagation()}} className="flight-menu-item" 
      style={{
       minHeight: "auto",
display: "flex",
justifyContent: "space-between",
gap:"1rem"
}}>

         {/* <ListItemIcon>
           <Settings fontSize="small" />
         </ListItemIcon> */}
          <ListItemIcon>
          <div className='list-item-text' 
       style={{display: "flex",
flexDirection: "column"}}
>
         <div className="upper-text">
         <div className='sub-text' style={{  display: "flex",
   alignItems: "center !important",
   alignContent: "center !important",
   justifyContent: "flex-start",
   gap: "6px"}}
   >
       <ChildFriendlyIcon />
       <span>Infants
       </span>
           </div>
        
         </div>
         <div className="lower-text"></div>
      
         {`(Age below 2 yrs)`}
       </div>
         
         </ListItemIcon>
         <Counter count={data.infants} onCountChange={updateInfants} />
       </MenuItem>
       {/* <Divider /> */}
       {/* <MenuItem onClick={handleClose}>
         <ListItemIcon>
           <Logout fontSize="small" />
         </ListItemIcon>
         Logout
       </MenuItem> */}
          
     </div>
     </Grid>
     </Grid>
                  <Grid container spacing={2} >
    
                  <Grid item sm={12} md={12} className='flight-last-columns'>
                  <button type="submit" className="form-submit-button small-size" onClick={handleSubmit}>
            Enquire Flights
          </button>
          <Link to="https://api.whatsapp.com/send?phone=918550895486&text=Greetings%20from%20Aventuras!%20%F0%9F%98%8A%0A%0APlease%20help%20us%20with%20the%20following%20so%20that%20we%20can%20assist%20you%20better%3A%0A1.%20Sector%20(%20From%20-%3E%20To%20airports)%0A2.%20Dates%20of%20travel%0A3.%20No.%20of%20travellers%0A4.%20Are%20dates%20flexible%20by%201%2C%202%C2%A0days%C2%A0%5BYes%C2%A0%2FNo%5D">
          <button type="submit" className="form-submit-button small-size" style={{margin:"1rem 0",textTransform:"inherit"}}>
           Click here for International flights enquiry 
          </button>
          </Link>
          {/* <Link to="https://api.whatsapp.com/send/?phone=917033323577&text=Hi+Aventuras+team%21+%0D+I+need+assistance+for+planning+my+travel.&type=phone_number&app_absent=0">
          <button type="submit" className="form-submit-button small-size" style={{margin:"1rem 0",textTransform:"inherit"}}>
           Click here for International flights enquiry 
          </button>
          </Link> */}
          </Grid>
          
                    </Grid>
                
                 
        </div>
      </Paper> 
        </div>
    </div>
</div>
</>
  )
}

export default FlightPageForm